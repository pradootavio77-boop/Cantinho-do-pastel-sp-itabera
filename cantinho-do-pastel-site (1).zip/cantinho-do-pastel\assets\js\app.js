/* Abas (por #endereço), dados do negócio na página, início e contato. */
(function () {
  const { D, esc, icone, fotoHTML, prepararFotos, linkWhats, menorPreco, reduzMovimento } = window.Base;
  const html = document.documentElement;

  // ---------- Dados do negócio em todos os lugares marcados ----------
  const enderecoCompleto = `${D.endereco} – ${D.bairro}, ${D.cidade}`;
  const campos = {
    endereco: D.endereco,
    'bairro-cidade': `${D.bairro}, ${D.cidade}`,
    telefone: D.telefone,
    arroba: `@${D.instagram}`,
  };
  document.querySelectorAll('[data-campo]').forEach((el) => { el.textContent = campos[el.dataset.campo] ?? el.textContent; });

  const mapa = encodeURIComponent(D.mapa);
  const links = {
    '[data-whats-oi]': linkWhats(`Olá, ${D.nomeCurto}! Vim pelo cardápio digital.`),
    '[data-link-mapa]': `https://www.google.com/maps/search/?api=1&query=${mapa}`,
    '[data-link-rota]': `https://www.google.com/maps/dir/?api=1&destination=${mapa}`,
    '[data-link-fone]': `tel:+${D.whatsapp}`,
    '[data-link-insta]': `https://www.instagram.com/${D.instagram}/`,
  };
  Object.entries(links).forEach(([sel, href]) => document.querySelectorAll(sel).forEach((a) => { a.href = href; }));
  document.querySelectorAll('[data-link-mapa]').forEach((a) => a.setAttribute('aria-label', `Abrir ${enderecoCompleto} no Google Maps`));

  // ---------- Letreiro gigante ao fundo das lousas ----------
  document.querySelectorAll('.marca-dagua[data-marca]').forEach((el) => {
    el.innerHTML = Array.from({ length: 6 }, () => `<span>${esc(el.dataset.marca)}</span>`).join('');
  });

  // ---------- Início ----------
  const fotoHeroi = { arquivo: 'real-calafrango', real: true, alt: 'Calafrango cortado ao meio, recheado de calabresa e frango, segurado na mão' };
  document.querySelector('[data-foto-heroi]').innerHTML = `
    ${fotoHTML(fotoHeroi, { sizes: '(min-width: 1024px) 480px, 80vw', eager: true })}
    <p class="heroi-legenda">“Calafrango caprichado não pode faltar”, no Instagram da casa</p>`;

  const cats = (grupo) => D.categorias.filter((c) => c.grupo === grupo);
  const linhaMenu = (c) => `<li><a href="#cardapio/${c.id}">
      <span class="menu-cat">${esc(c.nome)}${c.sub ? ` <small>${esc(c.sub.toLowerCase())}</small>` : ''}</span>
      <span class="menu-preco">a partir de <b>R$ ${menorPreco(c)}</b></span>
    </a></li>`;

  const paineis = [
    { grupo: 'pasteis', lousa: 'vermelha', titulo: 'Pastéis', foto: { arquivo: 'pastel-fritando', real: false, alt: 'Pastel dourando no óleo quente' }, chamada: 'Ver os pastéis', destino: 'pasteis-simples' },
    { grupo: 'lanches', lousa: 'preta', titulo: 'Lanches', foto: { arquivo: 'dog-na-mao', real: false, alt: 'Cachorro-quente com batata palha, embrulhado em papel' }, chamada: 'Ver hot dogs e lanches', destino: 'hot-dogs' },
  ];
  document.querySelector('[data-menus]').innerHTML = paineis.map((p) => {
    const lista = cats(p.grupo);
    const total = lista.reduce((s, c) => s + c.itens.length, 0);
    return `<article class="menu lousa lousa--${p.lousa}">
      <div class="marca-dagua" aria-hidden="true">${Array.from({ length: 6 }, () => `<span>${p.grupo === 'pasteis' ? 'PASTEL' : 'LANCHES'}</span>`).join('')}</div>
      ${fotoHTML(p.foto, { sizes: '(min-width: 900px) 540px, 100vw', classe: 'menu-foto' })}
      <div class="menu-corpo">
        <h3 class="menu-titulo">${p.titulo}</h3>
        <p class="menu-conta">${total} opções no cardápio</p>
        <ul class="menu-lista">${lista.map(linhaMenu).join('')}</ul>
        <a class="botao botao--gema" href="#cardapio/${p.destino}">${p.chamada}</a>
      </div>
    </article>`;
  }).join('');

  const posts = [
    { arquivo: 'real-duplo-catupiry', legenda: 'Duplo catupiry não pode faltar', data: '28 de abril de 2026', alt: 'Duplo catupiry cortado ao meio' },
    { arquivo: 'real-duplo-cheddar', legenda: 'Quem aí ama um cachorro quente duplo cheddar?', data: '28 de abril de 2026', alt: 'Cachorro-quente duplo cheddar cortado ao meio' },
  ];
  document.querySelector('[data-insta]').innerHTML = posts.map((p) => `
    <figure class="post">
      ${fotoHTML({ ...p, real: true }, { sizes: '(min-width: 900px) 360px, 50vw', etiqueta: false })}
      <figcaption><span class="post-texto">${esc(p.legenda)}</span><span class="post-data">${p.data}</span></figcaption>
    </figure>`).join('') + `
    <a class="post post--seguir" href="https://www.instagram.com/${D.instagram}/" target="_blank" rel="noopener">
      <img src="assets/img/logo-192.webp" width="96" height="96" alt="" loading="lazy">
      <span class="post-seguir-t">Siga o Cantinho</span>
      <span>@${esc(D.instagram)}</span>
      <span class="botao botao--gema">${icone('insta')} Abrir Instagram</span>
    </a>`;

  // ---------- Contato: horário, serviços e mapa ----------
  const caixaHorario = document.querySelector('[data-horario]');
  function horarioHTML() {
    if (!Array.isArray(D.horario) || D.horario.length !== 7) {
      return `<p>Confira o horário de hoje pelo WhatsApp antes de passar aqui.</p>
        <a class="botao botao--contorno-escuro" data-whats-horario target="_blank" rel="noopener" href="${linkWhats(`Olá, ${D.nomeCurto}! Qual o horário de vocês hoje?`)}">Perguntar o horário</a>`;
    }
    const agora = new Date(new Date().toLocaleString('en-US', { timeZone: D.fusoHorario }));
    const hoje = agora.getDay();
    const minutos = agora.getHours() * 60 + agora.getMinutes();
    const m = (h) => { const [a, b] = h.split(':').map(Number); return a * 60 + b; };
    const h = D.horario[hoje];
    let aberto = false;
    if (h.abre && h.fecha) {
      const ab = m(h.abre); let fe = m(h.fecha);
      if (fe <= ab) fe += 24 * 60; // fecha depois da meia-noite
      aberto = (minutos >= ab && minutos < fe) || (minutos + 1440 >= ab && minutos + 1440 < fe);
    }
    const ordem = [1, 2, 3, 4, 5, 6, 0];
    return `<p class="status-aberto ${aberto ? 'sim' : 'nao'}">${aberto ? 'Aberto agora' : 'Fechado agora'}</p>
      <table class="tabela-horario"><tbody>${ordem.map((i) => {
        const d = D.horario[i];
        return `<tr${i === hoje ? ' class="hoje"' : ''}><th scope="row">${esc(d.dia)}</th><td>${d.abre ? `${d.abre} às ${d.fecha}` : 'Fechado'}</td></tr>`;
      }).join('')}</tbody></table>`;
  }
  caixaHorario.insertAdjacentHTML('beforeend', horarioHTML());

  const servicos = document.querySelector('[data-servicos]');
  if (D.entrega || D.retirada || D.formasDePagamento) {
    servicos.hidden = false;
    servicos.innerHTML = `<h2>Retirada, entrega e pagamento</h2>
      ${D.retirada ? `<p>${esc(D.retirada)}</p>` : ''}${D.entrega ? `<p>${esc(D.entrega)}</p>` : ''}
      ${D.formasDePagamento ? `<p>Pagamento: ${esc(D.formasDePagamento.join(', '))}.</p>` : ''}`;
  }

  const iframeMapa = document.querySelector('[data-mapa]');
  let mapaCarregado = false;
  function carregarMapa() {
    if (mapaCarregado) return;
    mapaCarregado = true;
    iframeMapa.src = `https://www.google.com/maps?q=${mapa}&z=17&output=embed`;
  }

  prepararFotos(document);

  // ---------- Abas ----------
  const ABAS = ['inicio', 'cardapio', 'contato'];
  const TITULOS = {
    inicio: 'Cardápio | Cantinho do Pastel e Lanches – Itaberá',
    cardapio: 'Cardápio completo | Cantinho do Pastel e Lanches',
    contato: 'Endereço e contato | Cantinho do Pastel e Lanches',
  };
  const paginas = Object.fromEntries(ABAS.map((a) => [a, document.querySelector(`[data-pagina="${a}"]`)]));
  let abaAtual = null;

  function lerRota() {
    const [aba, sub] = location.hash.replace(/^#/, '').split('/');
    return { aba: ABAS.includes(aba) ? aba : 'inicio', sub };
  }

  function aplicar({ aba, sub }, { primeira = false } = {}) {
    const trocou = aba !== abaAtual;
    if (trocou) {
      ABAS.forEach((a) => { paginas[a].hidden = a !== aba; });
      document.querySelectorAll('[data-aba]').forEach((l) => {
        if (l.dataset.aba === aba) l.setAttribute('aria-current', 'page'); else l.removeAttribute('aria-current');
      });
      html.dataset.aba = aba;
      document.title = TITULOS[aba];
      abaAtual = aba;
      if (aba === 'contato') carregarMapa();
    }
    if (aba === 'cardapio' && sub) {
      setTimeout(() => window.Cardapio.irPara(sub, !trocou), 0);
    } else if (trocou && !primeira) {
      window.scrollTo(0, 0);
    }
    if (trocou && !primeira && !sub) paginas[aba].querySelector('h1')?.focus({ preventScroll: true });
  }

  function navegar() {
    const rota = lerRota();
    const trocaAba = rota.aba !== abaAtual;
    if (trocaAba && document.startViewTransition && !reduzMovimento()) {
      document.startViewTransition(() => aplicar(rota));
    } else {
      aplicar(rota);
    }
  }

  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  window.addEventListener('hashchange', navegar);
  aplicar(lerRota(), { primeira: true });

  // ---------- Entrada do herói (depois da abertura, ou logo de cara) ----------
  const heroi = document.querySelector('.heroi');
  function entrar() { heroi.classList.add('entrou'); }
  if (html.classList.contains('com-intro')) {
    document.addEventListener('cantinho:intro-saindo', entrar, { once: true });
    setTimeout(entrar, 7000); // garantia caso a abertura falhe
  } else {
    requestAnimationFrame(() => requestAnimationFrame(entrar));
  }
})();
