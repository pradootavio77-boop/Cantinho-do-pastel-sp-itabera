/* Cardápio: lousas por grupo, itens, busca, categorias e "+" rápido. */
(function () {
  const { D, precoHTML, normalizar, esc, icone, fotoHTML, prepararFotos, catPorId, menorPreco } = window.Base;

  const raiz = document.querySelector('[data-cardapio]');
  const chips = document.querySelector('[data-chips]');
  const campoBusca = document.querySelector('[data-busca]');
  const botaoLimpar = document.querySelector('[data-limpar-busca]');
  const status = document.querySelector('[data-busca-status]');

  const marcaDagua = (palavra, linhas = 8) => Array.from({ length: linhas }, () => `<span>${palavra}</span>`).join('');

  function itemHTML(item, cat) {
    const temFoto = item.foto && item.foto.real;
    const exigeEscolha = !!item.opcoes;
    return `<li class="item${temFoto ? ' item--foto' : ''}" data-item="${item.id}">
      <button type="button" class="item-abrir" data-abrir-item="${item.id}">
        ${temFoto ? `<span class="item-miniatura">${fotoHTML(item.foto, { sizes: '96px', etiqueta: false })}<span class="item-miniatura-tag">Foto da casa</span></span>` : ''}
        <span class="item-texto">
          <span class="item-nome">${esc(item.nome)}</span>
          ${item.desc ? `<span class="item-desc">${esc(item.desc)}</span>` : ''}
        </span>
        ${precoHTML(item.preco)}
      </button>
      <button type="button" class="item-mais" data-mais="${item.id}"
        aria-label="${exigeEscolha ? `Escolher opção e adicionar ${esc(item.nome)}` : `Adicionar ${esc(item.nome)} à sacola`}">
        ${icone('mais')}
      </button>
    </li>`;
  }

  function categoriaHTML(cat) {
    const n = cat.itens.length;
    const contagem = cat.id === 'bebidas' ? `${n} opções` : `${n} ${n === 1 ? 'opção' : 'opções'}`;
    return `<section class="categoria${cat.foto ? ' categoria--foto' : ''}" id="cat-${cat.id}" data-categoria="${cat.id}" aria-labelledby="ct-${cat.id}">
      ${cat.foto ? `<div class="categoria-foto">${fotoHTML(cat.foto, { sizes: '(min-width: 1100px) 1068px, 100vw' })}</div>` : ''}
      <div class="categoria-faixa">
        <h2 id="ct-${cat.id}">${esc(cat.nome)}</h2>
        ${cat.sub ? `<span class="categoria-sub">${esc(cat.sub)}</span>` : ''}
      </div>
      <p class="categoria-meta">${contagem}, a partir de R$ ${menorPreco(cat)}</p>
      ${cat.nota ? `<p class="categoria-nota">${esc(cat.nota)}</p>` : ''}
      <ul class="itens">${cat.itens.map((i) => itemHTML(i, cat)).join('')}</ul>
    </section>`;
  }

  function adicionaisHTML() {
    return `<section class="categoria categoria--adicionais" id="cat-adicionais" data-categoria="adicionais" aria-labelledby="ct-adicionais">
      <div class="categoria-faixa"><h2 id="ct-adicionais">Adicionais</h2></div>
      <p class="categoria-meta">Para hot dogs e lanches. Escolha ao abrir o item.</p>
      <ul class="adicionais-lista">
        ${D.adicionais.map((a) => `<li data-adicional="${a.id}"><span>${esc(a.nome)}</span>${precoHTML(a.preco)}</li>`).join('')}
      </ul>
    </section>`;
  }

  function render() {
    raiz.innerHTML = D.grupos.map((g) => {
      const cats = D.categorias.filter((c) => c.grupo === g.id);
      return `<div class="lousa lousa--${g.lousa} grupo" data-grupo="${g.id}">
        <div class="marca-dagua" aria-hidden="true">${marcaDagua(g.marca, 14)}</div>
        <div class="grupo-dentro">
          ${cats.map(categoriaHTML).join('')}
          ${g.id === 'lanches' ? adicionaisHTML() : ''}
        </div>
      </div>`;
    }).join('') + `<div class="cardapio-vazio" data-vazio hidden>
        <p>Nenhum item com “<b data-termo></b>”.</p>
        <p>Tente outro sabor ou ingrediente, como “frango” ou “catupiry”.</p>
        <button type="button" class="botao botao--gema" data-limpar-busca>Limpar busca</button>
      </div>`;

    const todas = [...D.categorias.map((c) => ({ id: c.id, nome: c.nome })), { id: 'adicionais', nome: 'Adicionais' }];
    chips.innerHTML = todas.map((c) => `<a class="chip" href="#cardapio/${c.id}" data-chip="${c.id}">${esc(c.nome)}</a>`).join('');
    prepararFotos(raiz);
  }

  // ---------- Busca (ignora acentos; procura em nome, ingredientes e categoria) ----------
  const indice = [];
  D.categorias.forEach((c) => c.itens.forEach((i) => indice.push({ id: i.id, cat: c.id, texto: normalizar(`${i.nome} ${i.desc} ${c.nome} ${c.rotulo}`) })));

  function buscar(termo) {
    const t = normalizar(termo.trim());
    botaoLimpar.hidden = !t;
    raiz.classList.toggle('buscando', !!t);
    const palavras = t.split(/\s+/).filter(Boolean);
    let achados = 0;
    const catsComItem = new Set();
    indice.forEach((reg) => {
      const ok = !t || palavras.every((p) => reg.texto.includes(p));
      const li = raiz.querySelector(`[data-item="${reg.id}"]`);
      li.hidden = !ok;
      if (ok) { achados++; catsComItem.add(reg.cat); }
    });
    raiz.querySelectorAll('[data-categoria]').forEach((sec) => {
      const id = sec.dataset.categoria;
      sec.hidden = !!t && (id === 'adicionais' ? !palavras.every((p) => normalizar('adicionais').includes(p)) : !catsComItem.has(id));
    });
    raiz.querySelectorAll('[data-grupo]').forEach((g) => {
      g.hidden = !!t && !g.querySelector('[data-categoria]:not([hidden])');
    });
    const vazio = raiz.querySelector('[data-vazio]');
    vazio.hidden = !t || achados > 0;
    vazio.querySelector('[data-termo]').textContent = termo.trim();
    chips.hidden = !!t;
    status.textContent = t ? (achados ? `${achados} ${achados === 1 ? 'item encontrado' : 'itens encontrados'} para “${termo.trim()}”` : '') : '';

    // Leva o começo dos resultados para logo abaixo da barra de busca.
    if (t) {
      const barra = document.querySelector('.cardapio-barra');
      const topo = document.querySelector('.topo');
      const alvo = status.getBoundingClientRect().top + window.scrollY - topo.offsetHeight - barra.offsetHeight;
      if (window.scrollY > alvo) window.scrollTo({ top: Math.max(0, alvo) });
    }
  }

  let espera;
  campoBusca.addEventListener('input', () => { clearTimeout(espera); espera = setTimeout(() => buscar(campoBusca.value), 120); });
  campoBusca.addEventListener('keydown', (e) => { if (e.key === 'Escape' && campoBusca.value) { e.preventDefault(); limpar(); } });
  function limpar() { campoBusca.value = ''; buscar(''); campoBusca.focus(); }
  document.addEventListener('click', (e) => { if (e.target.closest('[data-limpar-busca]')) limpar(); });

  // ---------- Categoria ativa enquanto rola ----------
  let ativa = null;
  function marcarChip(id, rolarChip = true) {
    if (id === ativa) return;
    ativa = id;
    chips.querySelectorAll('.chip').forEach((c) => {
      const sim = c.dataset.chip === id;
      c.classList.toggle('ativo', sim);
      if (sim) c.setAttribute('aria-current', 'true'); else c.removeAttribute('aria-current');
      // Rolagem instantânea: uma rolagem suave aqui cancelaria a rolagem suave da página no Chrome.
      if (sim && rolarChip) chips.scrollLeft = c.offsetLeft - chips.clientWidth / 2 + c.clientWidth / 2;
    });
  }

  // Enquanto a página rola até uma categoria escolhida, o destaque não fica pulando pelas do meio.
  let travaAte = 0;
  window.addEventListener('scrollend', () => { travaAte = 0; });

  function observar() {
    const obs = new IntersectionObserver((entradas) => {
      if (Date.now() < travaAte) return;
      entradas.forEach((en) => { if (en.isIntersecting) marcarChip(en.target.dataset.categoria); });
    }, { rootMargin: '-40% 0px -55% 0px' });
    raiz.querySelectorAll('[data-categoria]').forEach((s) => obs.observe(s));
  }

  function irPara(id, suave = true) {
    const alvo = document.getElementById(`cat-${id}`);
    if (!alvo) return;
    travaAte = Date.now() + 1200;
    marcarChip(id);
    alvo.scrollIntoView({ behavior: suave && !window.Base.reduzMovimento() ? 'smooth' : 'auto', block: 'start' });
  }

  chips.addEventListener('click', (e) => {
    const c = e.target.closest('[data-chip]');
    if (!c) return;
    e.preventDefault();
    history.replaceState(null, '', `#cardapio/${c.dataset.chip}`);
    irPara(c.dataset.chip);
  });

  // A altura real da barra (busca + categorias) define onde cada categoria para ao rolar.
  const barraEl = document.querySelector('.cardapio-barra');
  if ('ResizeObserver' in window) {
    new ResizeObserver(() => {
      if (barraEl.offsetHeight) document.documentElement.style.setProperty('--barra-cardapio', `${barraEl.offsetHeight}px`);
    }).observe(barraEl);
  }

  render();
  observar();
  buscar('');

  window.Cardapio = { irPara, catPorId };
})();
