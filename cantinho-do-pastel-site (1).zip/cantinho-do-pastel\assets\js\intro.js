/* Abertura (~3,6 s): o letreiro PASTEL se desenha, o selo da casa carimba,
   as marcas de garfo fecham o círculo, fotos reais abrem em leque e a lousa
   se parte ao meio como um pastel, enquanto o selo voa para o topo do site.
   Pula com o botão, com Esc/Enter ou tocando na tela. */
(function () {
  const html = document.documentElement;
  const intro = document.getElementById('intro');
  if (!intro) return;
  if (!html.classList.contains('com-intro')) { intro.remove(); return; }

  const $ = (s) => intro.querySelector(s);
  const fora = [document.querySelector('.topo'), document.querySelector('main'), document.querySelector('.rodape'), document.querySelector('.barra')].filter(Boolean);
  fora.forEach((el) => el.setAttribute('inert', ''));

  const fotos = [...intro.querySelectorAll('.intro-foto')];
  fotos.forEach((img) => { img.src = img.dataset.src; });

  const letreiro = $('.intro-letreiro text');
  const selo = $('.intro-selo');
  const logo = $('.intro-logo');
  const garfo = $('.intro-garfo-revela');
  const marcas = $('.intro-garfo-marcas');
  const palavras = [...intro.querySelectorAll('.intro-palavras span')];
  const local = $('.intro-local');
  const cima = $('.intro-metade--cima');
  const baixo = $('.intro-metade--baixo');
  const pular = $('.intro-pular');

  const animacoes = [];
  const anima = (el, quadros, opcoes) => {
    const a = el.animate(quadros, { fill: 'both', easing: 'cubic-bezier(.2,.7,.2,1)', ...opcoes });
    animacoes.push(a);
    return a;
  };
  const espera = (ms) => new Promise((r) => setTimeout(r, ms));
  const carregou = (img) => (img.complete ? Promise.resolve() : new Promise((r) => { img.onload = img.onerror = r; }));

  // Espera fontes e imagens (no máximo ~0,9 s) para não começar com letra trocada.
  const fontes = document.fonts ? Promise.all([
    document.fonts.load('800 120px "Barlow Condensed"'),
    document.fonts.load('400 40px "Ultra"'),
  ]).catch(() => {}) : Promise.resolve();
  const pronto = Promise.race([Promise.all([fontes, carregou(logo), ...fotos.map(carregou)]), espera(900)]);

  let timerSaida;
  let saiu = false;

  // Posição final do leque: depende do tamanho da tela.
  function leque() {
    const largo = window.innerWidth >= 720;
    const dx = largo ? Math.min(window.innerWidth * 0.2, 260) : window.innerWidth * 0.27;
    return [
      { x: -dx, y: largo ? -10 : -6, r: -13 },
      { x: 0, y: largo ? -60 : -46, r: 2 },
      { x: dx, y: largo ? -6 : -2, r: 12 },
    ];
  }

  pronto.then(() => {
    if (saiu) return;
    intro.classList.add('rodando');

    // 1) Letreiro gigante se desenha e depois ganha preenchimento escuro, como no cardápio impresso.
    anima(letreiro, [{ strokeDashoffset: 1400, fillOpacity: 0 }, { strokeDashoffset: 0, fillOpacity: 0, offset: 0.75 }, { strokeDashoffset: 0, fillOpacity: 1 }], { duration: 1500, easing: 'cubic-bezier(.45,0,.25,1)' });

    // 2) Selo carimba.
    anima(selo, [
      { transform: 'scale(1.5) rotate(-14deg)', opacity: 0, filter: 'blur(10px)' },
      { transform: 'scale(.94) rotate(2deg)', opacity: 1, filter: 'blur(0)', offset: 0.7 },
      { transform: 'scale(1) rotate(0deg)', opacity: 1, filter: 'blur(0)' },
    ], { duration: 820, delay: 260, easing: 'cubic-bezier(.3,.6,.25,1)' });

    // 3) Marcas de garfo fecham o círculo.
    anima(garfo, [{ strokeDashoffset: 100 }, { strokeDashoffset: 0 }], { duration: 900, delay: 820, easing: 'cubic-bezier(.6,0,.3,1)' });

    // 4) Palavras, uma de cada vez.
    palavras.forEach((p, i) => anima(p, [
      { transform: 'translateY(70%) rotate(-6deg)', opacity: 0 },
      { transform: 'translateY(0) rotate(0)', opacity: 1 },
    ], { duration: 520, delay: 1150 + i * 190, easing: 'cubic-bezier(.2,.9,.25,1.2)' }));
    anima(local, [{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 500, delay: 1800 });

    // 5) Fotos reais abrem em leque atrás do selo.
    leque().forEach((pos, i) => anima(fotos[i], [
      { transform: 'translate(-50%, -50%) translate(0px, 30px) rotate(0deg) scale(.55)', opacity: 0 },
      { transform: `translate(-50%, -50%) translate(${pos.x}px, ${pos.y}px) rotate(${pos.r}deg) scale(1)`, opacity: 1 },
    ], { duration: 850, delay: 1450 + i * 120, easing: 'cubic-bezier(.2,.9,.2,1.08)' }));

    timerSaida = setTimeout(() => sair(false), 3050);
  });

  function sair(rapido) {
    if (saiu) return;
    saiu = true;
    clearTimeout(timerSaida);
    // Congela tudo onde está e parte dali.
    animacoes.forEach((a) => { try { a.commitStyles(); } catch (e) { /* elemento sem estilo */ } a.cancel(); });

    const t = rapido ? 0.6 : 1;
    const fim = { fill: 'forwards' };
    document.dispatchEvent(new CustomEvent('cantinho:intro-saindo'));
    intro.classList.add('saindo');

    // Selo voa até o logo do topo.
    const alvo = document.querySelector('.topo-logo');
    const a = selo.getBoundingClientRect();
    const b = alvo && alvo.getBoundingClientRect();
    if (b && b.width) {
      const cx = b.left + b.width / 2 - (a.left + a.width / 2);
      const cy = b.top + b.height / 2 - (a.top + a.height / 2);
      const esc = (b.width / logo.getBoundingClientRect().width) || 0.2;
      selo.animate([{ transform: getComputedStyle(selo).transform === 'none' ? 'none' : getComputedStyle(selo).transform, opacity: 1 }, { transform: `translate(${cx}px, ${cy}px) scale(${esc})`, opacity: 1 }], { duration: 760 * t, easing: 'cubic-bezier(.7,0,.2,1)', ...fim });
    } else {
      selo.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300 * t, ...fim });
    }
    marcas.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 220 * t, ...fim });
    letreiro.closest('svg').animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300 * t, ...fim });
    [local, ...palavras].forEach((el) => el.animate([{ opacity: getComputedStyle(el).opacity }, { opacity: 0, transform: 'scale(1.06)' }], { duration: 300 * t, ...fim }));
    fotos.forEach((f, i) => {
      const atual = getComputedStyle(f).transform;
      f.animate([{ transform: atual, opacity: getComputedStyle(f).opacity }, { transform: `${atual === 'none' ? '' : atual} translateY(${i === 1 ? -40 : 40}px) scale(1.1)`, opacity: 0 }], { duration: 380 * t, easing: 'ease-in', ...fim });
    });
    pular.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 200, ...fim });

    // A lousa se parte ao meio como um pastel aberto.
    const abre = { duration: 820 * t, delay: 140 * t, easing: 'cubic-bezier(.77,0,.18,1)', ...fim };
    cima.animate([{ transform: 'translateY(0)' }, { transform: 'translateY(-101%)' }], abre);
    const ultima = baixo.animate([{ transform: 'translateY(0)' }, { transform: 'translateY(101%)' }], abre);

    ultima.finished.then(() => {
      fora.forEach((el) => el.removeAttribute('inert'));
      html.classList.remove('com-intro');
      try { sessionStorage.setItem('cantinho:intro', '1'); } catch (e) { /* sem armazenamento */ }
      intro.remove();
      document.dispatchEvent(new CustomEvent('cantinho:intro-fim'));
    });
  }

  pular.addEventListener('click', (e) => { e.stopPropagation(); sair(true); });
  intro.addEventListener('click', () => sair(true));
  document.addEventListener('keydown', function tecla(e) {
    if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') {
      if (document.activeElement === pular && e.key !== 'Escape') return; // o próprio botão já trata
      document.removeEventListener('keydown', tecla);
      sair(true);
    }
  });
  pular.focus({ preventScroll: true });
})();
