/* Folhas (janelas) do item e da sacola, avisos com "Desfazer" e contador da sacola. */
(function () {
  const { D, reais, precoHTML, esc, icone, fotoHTML, prepararFotos, itensPorId, linkWhats, reduzMovimento } = window.Base;
  const Sacola = window.Sacola;

  // ---------- Abrir/fechar com animação (o <dialog> cuida do foco e do Esc) ----------
  function abrir(dlg) {
    if (dlg.open) return;
    dlg.showModal();
    document.documentElement.classList.add('travado');
    requestAnimationFrame(() => dlg.classList.add('aberta'));
  }
  function fechar(dlg) {
    if (!dlg.open || dlg.classList.contains('fechando')) return;
    dlg.classList.remove('aberta');
    dlg.classList.add('fechando');
    const fim = () => {
      dlg.classList.remove('fechando');
      dlg.close();
      if (!document.querySelector('dialog[open]')) document.documentElement.classList.remove('travado');
    };
    if (reduzMovimento()) fim(); else setTimeout(fim, 240);
  }
  document.querySelectorAll('dialog.folha').forEach((dlg) => {
    dlg.addEventListener('cancel', (e) => { e.preventDefault(); fechar(dlg); });
    dlg.addEventListener('click', (e) => {
      if (e.target === dlg || e.target.closest('[data-fechar]')) fechar(dlg);
    });
  });

  // ---------- Avisos ----------
  const caixaAvisos = document.querySelector('[data-avisos]');
  let timerAviso;
  function aviso(texto, acoes = []) {
    clearTimeout(timerAviso);
    // Com uma janela aberta, o aviso precisa ficar dentro dela para aparecer por cima.
    const alvo = document.querySelector('dialog.folha[open]:not(.fechando)') || document.body;
    if (caixaAvisos.parentElement !== alvo) alvo.appendChild(caixaAvisos);
    caixaAvisos.innerHTML = `<div class="aviso">${icone('check')}<span>${esc(texto)}</span>
      ${acoes.map((a, i) => `<button type="button" data-acao="${i}">${esc(a.rotulo)}</button>`).join('')}</div>`;
    const caixa = caixaAvisos.firstElementChild;
    acoes.forEach((a, i) => caixa.querySelector(`[data-acao="${i}"]`).addEventListener('click', () => { a.fazer(); some(); }));
    requestAnimationFrame(() => caixa.classList.add('visivel'));
    const some = () => { caixa.classList.remove('visivel'); setTimeout(() => caixa.remove(), 250); };
    timerAviso = setTimeout(some, 5000);
  }

  // ---------- Contador ----------
  function atualizarContador() {
    const n = Sacola.quantidade();
    document.querySelectorAll('[data-contador]').forEach((c) => {
      const mudou = c.textContent !== String(n);
      c.textContent = n;
      c.hidden = n === 0;
      if (mudou && n > 0 && !reduzMovimento()) { c.classList.remove('pulou'); void c.offsetWidth; c.classList.add('pulou'); }
    });
    document.querySelectorAll('[data-abrir-sacola]').forEach((b) => b.setAttribute('aria-label', n ? `Sacola, ${n} ${n === 1 ? 'item' : 'itens'}` : 'Sacola vazia'));
  }

  // ---------- Item ----------
  const dlgItem = document.getElementById('folha-item');
  const formItem = dlgItem.querySelector('[data-form-item]');
  let atual = null;

  function lousaDoItem(item, cat) {
    const grupo = D.grupos.find((g) => g.id === cat.grupo);
    return `<div class="fi-lousa lousa lousa--${grupo.lousa}">
      <div class="marca-dagua" aria-hidden="true">${Array.from({ length: 5 }, () => `<span>${grupo.marca}</span>`).join('')}</div>
      <h2 id="fi-nome" class="fi-lousa-nome">${esc(item.nome)}</h2>
    </div>`;
  }

  function abrirItem(id) {
    const { item, cat } = itensPorId.get(id);
    atual = { item, cat, qtd: 1 };
    const adicionais = cat.aceitaAdicionais ? D.adicionais : [];
    const midia = item.foto ? `<div class="fi-midia">${fotoHTML(item.foto, { sizes: '(min-width: 720px) 560px, 100vw', eager: true })}</div>` : lousaDoItem(item, cat);

    formItem.innerHTML = `
      <div class="folha-cabeca folha-cabeca--flutua">
        <button type="button" class="botao-icone" data-fechar aria-label="Fechar">${icone('fechar')}</button>
      </div>
      <div class="folha-rolagem">
        ${midia}
        <div class="fi-corpo">
          <p class="fi-cat">${esc(cat.nome)}${cat.sub ? `, ${esc(cat.sub.toLowerCase())}` : ''}</p>
          ${item.foto ? `<h2 id="fi-nome" class="fi-nome">${esc(item.nome)}</h2>` : ""}
          ${item.desc ? `<p class="fi-desc">${esc(item.desc)}</p>` : ''}
          ${cat.nota ? `<p class="fi-nota">${esc(cat.nota)}</p>` : ''}
          <p class="fi-preco">${precoHTML(item.preco)}</p>
          ${item.opcoes ? `<fieldset class="fi-grupo" data-opcoes>
            <legend>${esc(item.opcoes.titulo)} <span class="obrigatorio">obrigatório</span></legend>
            ${item.opcoes.escolhas.map((o, i) => `<label class="opcao"><input type="radio" name="opcao" value="${esc(o)}" ${i === 0 ? 'required' : ''}><span>${esc(o)}</span></label>`).join('')}
            <p class="fi-erro" data-erro hidden>Escolha uma opção para continuar.</p>
          </fieldset>` : ''}
          ${adicionais.length ? `<fieldset class="fi-grupo">
            <legend>Adicionais <span class="opcional">opcional</span></legend>
            <div class="fi-adicionais">
            ${adicionais.map((a) => `<label class="opcao opcao--check"><input type="checkbox" name="adicional" value="${a.id}"><span>${esc(a.nome)}</span><span class="opcao-preco">+ ${reais(a.preco)}</span></label>`).join('')}
            </div>
          </fieldset>` : ''}
          <label class="fi-obs">
            <span>Alguma observação?</span>
            <textarea name="obs" rows="2" maxlength="140" placeholder="Ex.: sem cebola, bem passado"></textarea>
          </label>
        </div>
      </div>
      <div class="folha-pe folha-pe--item">
        <div class="passo" role="group" aria-label="Quantidade">
          <button type="button" class="botao-icone" data-qtd="-1" aria-label="Diminuir quantidade">${icone('menos')}</button>
          <output data-qtd-valor aria-live="polite">1</output>
          <button type="button" class="botao-icone" data-qtd="1" aria-label="Aumentar quantidade">${icone('mais')}</button>
        </div>
        <button type="submit" class="botao botao--gema botao--grande fi-adicionar"><span>Adicionar</span><span data-total-item>${reais(item.preco)}</span></button>
      </div>`;
    prepararFotos(formItem);
    abrir(dlgItem);
    formItem.querySelector('.folha-rolagem').scrollTop = 0;
  }

  function lerItem() {
    const adicionais = [...formItem.querySelectorAll('input[name="adicional"]:checked')].map((i) => i.value);
    const opcao = formItem.querySelector('input[name="opcao"]:checked')?.value || '';
    const obs = formItem.querySelector('textarea[name="obs"]').value;
    return { adicionais, opcao, obs };
  }

  function atualizarTotalItem() {
    if (!atual) return;
    const { adicionais } = lerItem();
    const unit = atual.item.preco + adicionais.reduce((s, id) => s + Sacola.adicional(id).preco, 0);
    formItem.querySelector('[data-total-item]').textContent = reais(unit * atual.qtd);
    formItem.querySelector('[data-qtd-valor]').textContent = atual.qtd;
    formItem.querySelector('[data-qtd="-1"]').disabled = atual.qtd <= 1;
  }

  formItem.addEventListener('change', (e) => {
    atualizarTotalItem();
    if (e.target.name === 'opcao') formItem.querySelector('[data-erro]').hidden = true;
  });
  formItem.addEventListener('click', (e) => {
    const b = e.target.closest('[data-qtd]');
    if (!b) return;
    atual.qtd = Math.max(1, Math.min(50, atual.qtd + Number(b.dataset.qtd)));
    atualizarTotalItem();
  });
  formItem.addEventListener('submit', (e) => {
    e.preventDefault();
    const { adicionais, opcao, obs } = lerItem();
    if (atual.item.opcoes && !opcao) {
      const erro = formItem.querySelector('[data-erro]');
      erro.hidden = false;
      formItem.querySelector('[data-opcoes]').scrollIntoView({ block: 'center', behavior: reduzMovimento() ? 'auto' : 'smooth' });
      formItem.querySelector('input[name="opcao"]').focus({ preventScroll: true });
      return;
    }
    const antes = Sacola.adicionar({ itemId: atual.item.id, qtd: atual.qtd, opcao, adicionais, obs });
    fechar(dlgItem);
    avisarAdicionado(atual.item, atual.qtd, antes);
  });

  function avisarAdicionado(item, qtd, antes) {
    aviso(`${qtd > 1 ? `${qtd}x ` : ''}${item.nome} na sacola`, [
      { rotulo: 'Desfazer', fazer: () => Sacola.restaurar(antes) },
      { rotulo: 'Ver sacola', fazer: abrirSacola },
    ]);
  }

  // "+" rápido: adiciona 1; se o item exige escolha (ex.: sabor), abre o detalhe.
  document.addEventListener('click', (e) => {
    const mais = e.target.closest('[data-mais]');
    if (mais) {
      const { item } = itensPorId.get(mais.dataset.mais);
      if (item.opcoes) { abrirItem(item.id); return; }
      const antes = Sacola.adicionar({ itemId: item.id });
      if (!reduzMovimento()) { mais.classList.remove('foi'); void mais.offsetWidth; mais.classList.add('foi'); }
      avisarAdicionado(item, 1, antes);
      return;
    }
    const abrirBtn = e.target.closest('[data-abrir-item]');
    if (abrirBtn) abrirItem(abrirBtn.dataset.abrirItem);
    if (e.target.closest('[data-abrir-sacola]')) abrirSacola();
  });

  // ---------- Sacola ----------
  const dlgSacola = document.getElementById('folha-sacola');
  const corpo = dlgSacola.querySelector('[data-sacola-corpo]');
  const pe = dlgSacola.querySelector('[data-sacola-pe]');

  corpo.innerHTML = `
    <div data-sacola-linhas></div>
    <div class="sacola-campos" data-sacola-campos>
      <label><span>Seu nome <span class="opcional">opcional</span></span><input type="text" name="nome" autocomplete="given-name" maxlength="60" placeholder="Para a casa saber quem pediu"></label>
      <label><span>Observações do pedido <span class="opcional">opcional</span></span><textarea name="obs" rows="2" maxlength="200" placeholder="Algo que a casa precise saber"></textarea></label>
    </div>`;
  const areaLinhas = corpo.querySelector('[data-sacola-linhas]');
  const campos = corpo.querySelector('[data-sacola-campos]');
  campos.addEventListener('input', (e) => Sacola.definirExtras({ [e.target.name]: e.target.value }));

  function servicosTexto() {
    const partes = [];
    if (D.retirada) partes.push(D.retirada);
    if (D.entrega) partes.push(D.entrega);
    if (D.formasDePagamento) partes.push(`Pagamento: ${D.formasDePagamento.join(', ')}.`);
    return partes.length ? partes.join(' ') : 'Como receber e como pagar você combina com a casa na conversa.';
  }

  function renderSacola() {
    const linhas = Sacola.linhas();
    if (!linhas.length) {
      areaLinhas.innerHTML = `<div class="sacola-vazia">
        ${icone('sacola', 'sacola-vazia-ico')}
        <p class="sacola-vazia-titulo">Sua sacola está vazia</p>
        <p>Escolha um pastel, um lanche ou uma bebida no cardápio.</p>
        <a class="botao botao--gema" href="#cardapio" data-fechar>Abrir cardápio</a>
      </div>`;
      campos.hidden = true;
      pe.innerHTML = '';
      pe.hidden = true;
      return;
    }
    campos.hidden = false;
    pe.hidden = false;
    areaLinhas.innerHTML = `<ul class="sacola-lista">${linhas.map((l) => {
      const { titulo, tipo, detalhe } = Sacola.descricaoLinha(l);
      const extras = l.adicionais.map((id) => Sacola.adicional(id)).map((a) => `+ ${esc(a.nome)}`).join(', ');
      return `<li class="sacola-linha" data-chave="${esc(l.chave)}">
        <div class="sacola-linha-texto">
          ${tipo ? `<p class="sacola-linha-tipo">${esc(tipo)}</p>` : ''}
          <p class="sacola-linha-nome">${esc(titulo)}</p>
          ${detalhe ? `<p class="sacola-linha-det">${esc(detalhe)}</p>` : ''}
          ${extras ? `<p class="sacola-linha-det">${extras}</p>` : ''}
          ${l.obs ? `<p class="sacola-linha-det">Obs.: ${esc(l.obs)}</p>` : ''}
          <p class="sacola-linha-unit">${reais(Sacola.precoUnitario(l))} cada</p>
        </div>
        <div class="sacola-linha-lado">
          <p class="sacola-linha-total">${reais(Sacola.precoUnitario(l) * l.qtd)}</p>
          <div class="passo passo--mini" role="group" aria-label="Quantidade de ${esc(titulo)}">
            <button type="button" class="botao-icone" data-linha-qtd="-1" aria-label="${l.qtd === 1 ? `Remover ${esc(titulo)}` : `Diminuir ${esc(titulo)}`}">${icone(l.qtd === 1 ? 'lixo' : 'menos')}</button>
            <output>${l.qtd}</output>
            <button type="button" class="botao-icone" data-linha-qtd="1" aria-label="Aumentar ${esc(titulo)}">${icone('mais')}</button>
          </div>
          <button type="button" class="link-remover" data-linha-remover>Remover</button>
        </div>
      </li>`;
    }).join('')}</ul>
    <button type="button" class="link-esvaziar" data-esvaziar>${icone('lixo')} Esvaziar sacola</button>`;

    pe.innerHTML = `
      <div class="sacola-total"><span>Total dos itens</span><strong>${reais(Sacola.total())}</strong></div>
      <p class="sacola-nota">${esc(servicosTexto())}</p>
      <a class="botao botao--folha botao--grande botao--largo" data-enviar target="_blank" rel="noopener">${icone('whats')} Enviar pedido no WhatsApp</a>`;
    atualizarLinkEnvio();
  }

  function atualizarLinkEnvio() {
    const a = pe.querySelector('[data-enviar]');
    if (a) a.href = linkWhats(Sacola.mensagem());
  }

  areaLinhas.addEventListener('click', (e) => {
    const li = e.target.closest('[data-chave]');
    if (e.target.closest('[data-esvaziar]')) {
      const antes = Sacola.esvaziar();
      aviso('Sacola esvaziada', [{ rotulo: 'Desfazer', fazer: () => Sacola.restaurar(antes) }]);
      return;
    }
    if (!li) return;
    const chave = li.dataset.chave;
    const qtd = e.target.closest('[data-linha-qtd]');
    if (qtd) {
      const delta = Number(qtd.dataset.linhaQtd);
      const linha = Sacola.linhas().find((l) => l.chave === chave);
      const saiu = linha && linha.qtd + delta <= 0;
      const titulo = linha && Sacola.descricaoLinha(linha).titulo;
      const antes = Sacola.mudarQtd(chave, delta);
      if (saiu) aviso(`${titulo} removido`, [{ rotulo: 'Desfazer', fazer: () => Sacola.restaurar(antes) }]);
      else focarDepois(chave, `[data-linha-qtd="${delta}"]`);
      return;
    }
    if (e.target.closest('[data-linha-remover]')) {
      const linha = Sacola.linhas().find((l) => l.chave === chave);
      const antes = Sacola.remover(chave);
      aviso(`${Sacola.descricaoLinha(linha).titulo} removido`, [{ rotulo: 'Desfazer', fazer: () => Sacola.restaurar(antes) }]);
    }
  });

  // Depois de redesenhar a lista, devolve o foco ao mesmo botão.
  function focarDepois(chave, seletor) {
    const li = [...areaLinhas.querySelectorAll('[data-chave]')].find((x) => x.dataset.chave === chave);
    li?.querySelector(seletor)?.focus();
  }

  pe.addEventListener('click', (e) => {
    if (!e.target.closest('[data-enviar]')) return;
    setTimeout(() => aviso('Pedido aberto no WhatsApp. É só tocar em enviar na conversa.', [
      { rotulo: 'Esvaziar sacola', fazer: () => { Sacola.esvaziar(); } },
    ]), 400);
  });

  function abrirSacola() {
    renderSacola();
    abrir(dlgSacola);
  }

  Sacola.ouvir((tipo) => {
    if (tipo === 'extras') { atualizarLinkEnvio(); return; }
    atualizarContador();
    if (dlgSacola.open) renderSacola();
  });
  atualizarContador();

  window.Folhas = { abrirItem, abrirSacola, fechar, aviso };
})();
