/* Sacola: estado do pedido, salvo no aparelho, e a mensagem para o WhatsApp.
   Os preços nunca são salvos: sempre vêm do cardápio atual (dados.js). */
(function () {
  const { D, reais, itensPorId } = window.Base;
  const CHAVE = 'cantinho:sacola:v1';
  const adicionalPorId = new Map(D.adicionais.map((a) => [a.id, a]));

  let linhas = carregar();
  let extras = { nome: '', obs: '' };
  const ouvintes = new Set();

  function carregar() {
    try {
      const salvo = JSON.parse(localStorage.getItem(CHAVE) || '[]');
      // Descarta itens que saíram do cardápio ou adicionais que não existem mais.
      return salvo.filter((l) => itensPorId.has(l.itemId) && l.qtd > 0).map((l) => {
        const limpa = { ...l, adicionais: (l.adicionais || []).filter((id) => adicionalPorId.has(id)) };
        limpa.chave = chaveDe(limpa);
        return limpa;
      });
    } catch (e) { return []; }
  }

  function salvar() {
    try { localStorage.setItem(CHAVE, JSON.stringify(linhas)); } catch (e) { /* modo privado: segue só na memória */ }
  }

  function avisar() { salvar(); ouvintes.forEach((fn) => fn()); }

  function chaveDe(l) {
    return [l.itemId, l.opcao || '', [...(l.adicionais || [])].sort().join('+'), (l.obs || '').trim().toLowerCase()].join('|');
  }

  function precoUnitario(l) {
    const { item } = itensPorId.get(l.itemId);
    return item.preco + (l.adicionais || []).reduce((s, id) => s + adicionalPorId.get(id).preco, 0);
  }

  const copia = () => linhas.map((l) => ({ ...l, adicionais: [...l.adicionais] }));

  const Sacola = {
    linhas: () => linhas,
    quantidade: () => linhas.reduce((s, l) => s + l.qtd, 0),
    total: () => linhas.reduce((s, l) => s + precoUnitario(l) * l.qtd, 0),
    precoUnitario,
    adicional: (id) => adicionalPorId.get(id),
    ouvir(fn) { ouvintes.add(fn); return () => ouvintes.delete(fn); },

    // Cada mudança devolve o estado anterior, para o botão "Desfazer".
    adicionar({ itemId, qtd = 1, opcao = '', adicionais = [], obs = '' }) {
      const antes = copia();
      const nova = { itemId, qtd, opcao, adicionais: [...adicionais], obs: obs.trim() };
      nova.chave = chaveDe(nova);
      const igual = linhas.find((l) => l.chave === nova.chave);
      if (igual) igual.qtd += qtd; else linhas.push(nova);
      avisar();
      return antes;
    },
    mudarQtd(chave, delta) {
      const antes = copia();
      const l = linhas.find((x) => x.chave === chave);
      if (!l) return antes;
      l.qtd += delta;
      if (l.qtd <= 0) linhas = linhas.filter((x) => x !== l);
      avisar();
      return antes;
    },
    remover(chave) {
      const antes = copia();
      linhas = linhas.filter((l) => l.chave !== chave);
      avisar();
      return antes;
    },
    esvaziar() {
      const antes = copia();
      linhas = [];
      avisar();
      return antes;
    },
    restaurar(estado) { linhas = estado; avisar(); },

    definirExtras(campos) { extras = { ...extras, ...campos }; ouvintes.forEach((fn) => fn('extras')); },
    extras: () => extras,

    descricaoLinha(l) {
      const { item, cat } = itensPorId.get(l.itemId);
      const partes = [];
      if (l.opcao) partes.push(`${item.opcoes.rotulo}: ${l.opcao}`);
      if (item.naMensagem) partes.push(item.naMensagem);
      return { titulo: item.nome, tipo: cat.rotulo, detalhe: partes.join(', '), cat };
    },

    mensagem() {
      const L = [`Olá, ${D.nomeCurto}! Quero fazer este pedido pelo cardápio digital:`, ''];
      linhas.forEach((l) => {
        const { titulo, tipo, detalhe } = Sacola.descricaoLinha(l);
        L.push(`*${l.qtd}x ${titulo}*${tipo ? ` (${tipo})` : ''} — ${reais(precoUnitario(l) * l.qtd)}`);
        if (detalhe) L.push(`   ${detalhe}`);
        l.adicionais.forEach((id) => {
          const a = adicionalPorId.get(id);
          L.push(`   + ${a.nome} (${reais(a.preco)})`);
        });
        if (l.obs) L.push(`   Obs.: ${l.obs}`);
      });
      L.push('', `*Total dos itens: ${reais(Sacola.total())}*`);
      if (extras.nome.trim()) L.push(`Nome: ${extras.nome.trim()}`);
      if (extras.obs.trim()) L.push(`Observações: ${extras.obs.trim()}`);
      return L.join('\n');
    },
  };

  window.Sacola = Sacola;
})();
