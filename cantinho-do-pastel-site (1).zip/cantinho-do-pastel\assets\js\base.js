/* Utilidades compartilhadas: preço, busca, ícones, fotos, WhatsApp. */
(function () {
  const D = window.CANTINHO;

  // Proporção (largura x altura) das fotos em assets/img/fotos — evita salto de layout.
  const FOTOS = {
    'pastel-fritando': [1800, 2700],
    'pasteis-prato': [1800, 2355],
    'pasteis-travessa': [1800, 1200],
    'pastel-doce': [1800, 2400],
    'dog-na-mao': [1800, 2700],
    'lanche-fundo-vermelho': [1800, 2700],
    'milkshakes': [1800, 2700],
    'real-calafrango': [1536, 2048],
    'real-duplo-catupiry': [1536, 2048],
    'real-duplo-cheddar': [1845, 2048],
  };

  const moeda = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
  const reais = (v) => moeda.format(v).replace(/ /g, ' ');

  // "R$" pequeno e número grande, como nos cardápios impressos.
  function precoHTML(v) {
    const [int, cent] = v.toFixed(2).split('.');
    return `<span class="preco"><small>R$</small>${int}${cent !== '00' ? `<sup>,${cent}</sup>` : ''}</span>`;
  }

  const normalizar = (s) => (s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function icone(nome, classe = '') {
    return `<svg class="ico ${classe}" aria-hidden="true" focusable="false"><use href="#i-${nome}"/></svg>`;
  }

  // <figure> com srcset, etiqueta "Foto da casa"/"Imagem ilustrativa" e tratamento de erro.
  function fotoHTML(f, { sizes = '100vw', classe = '', eager = false, etiqueta = true } = {}) {
    if (!f) return '';
    const [w, h] = FOTOS[f.arquivo] || [4, 3];
    const base = `assets/img/fotos/${f.arquivo}`;
    const tag = etiqueta ? `<span class="foto-tag${f.real ? ' foto-tag--real' : ''}">${f.real ? esc(f.legenda || 'Foto da casa') : 'Imagem ilustrativa'}</span>` : '';
    return `<figure class="foto ${classe}">
      <img src="${base}-640.webp" srcset="${base}-640.webp 640w, ${base}-1280.webp 1280w" sizes="${sizes}"
        width="${w}" height="${h}" alt="${esc(f.alt || '')}" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async">
      ${tag}
    </figure>`;
  }

  // Marca a foto como carregada (some o brilho de espera) ou com erro (mostra aviso).
  function prepararFotos(raiz = document) {
    raiz.querySelectorAll('figure.foto img:not([data-ok])').forEach((img) => {
      img.dataset.ok = '1';
      const fig = img.closest('figure');
      const ok = () => fig.classList.add('carregou');
      const erro = () => fig.classList.add('falhou');
      if (img.complete) (img.naturalWidth ? ok() : erro());
      else { img.addEventListener('load', ok, { once: true }); img.addEventListener('error', erro, { once: true }); }
    });
  }

  const linkWhats = (texto) => `https://wa.me/${D.whatsapp}${texto ? `?text=${encodeURIComponent(texto)}` : ''}`;

  // Índices para achar item/categoria rapidamente.
  const itensPorId = new Map();
  const catPorId = new Map();
  D.categorias.forEach((c) => {
    catPorId.set(c.id, c);
    c.itens.forEach((i) => itensPorId.set(i.id, { item: i, cat: c }));
  });

  const menorPreco = (c) => Math.min(...c.itens.map((i) => i.preco));


  const reduzMovimento = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  window.Base = { D, reais, precoHTML, normalizar, esc, icone, fotoHTML, prepararFotos, linkWhats, itensPorId, catPorId, menorPreco, reduzMovimento };
})();
