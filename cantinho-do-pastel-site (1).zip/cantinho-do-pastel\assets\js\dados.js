/* ============================================================
   Cantinho do Pastel e Lanches · dados do negócio e cardápio
   Tudo o que muda (preços, sabores, contato, horário) se edita
   SÓ aqui. Fonte: cardápios impressos e Instagram da casa.
   ============================================================ */
window.CANTINHO = {
  nome: 'Cantinho do Pastel e Lanches',
  nomeCurto: 'Cantinho do Pastel',
  cidade: 'Itaberá – SP',

  // WhatsApp com código do país (55) + DDD, sem espaços nem sinais.
  whatsapp: '5515992784602',
  telefone: '(15) 99278-4602',
  instagram: 'cantinhodopastel_itabera',

  endereco: 'Av. Coronel José Pedro de Lima, 59',
  bairro: 'Centro',
  cep: '18440-000',
  // O que o mapa procura (o Google Maps registra a via como "R. Cel. José Pedro de Lima").
  mapa: 'R. Cel. José Pedro de Lima, 59 - Centro, Itaberá - SP, 18440-000',

  // PENDENTE: horário ainda não confirmado com a casa.
  // Quando souber, troque null por uma lista com os 7 dias (0 = domingo … 6 = sábado):
  // [{ dia: 'Domingo', abre: '18:00', fecha: '23:00' }, … ]  — dia fechado: { dia: 'Segunda', abre: null, fecha: null }
  horario: null,
  fusoHorario: 'America/Sao_Paulo',

  // PENDENTE: confirmar com a casa. Enquanto for null, o site não promete nada disso.
  // Ex.: entrega: 'Entregamos em Itaberá; a taxa depende do bairro.'
  entrega: null,
  retirada: null,
  formasDePagamento: null, // ex.: ['Dinheiro', 'Pix', 'Cartão']

  // Adicionais (cardápio de lanches). Valem para hot dogs e lanches salgados.
  adicionais: [
    { id: 'catupiry', nome: 'Catupiry', preco: 5 },
    { id: 'cheddar', nome: 'Cheddar', preco: 5 },
    { id: 'cream-cheese', nome: 'Cream cheese', preco: 5 },
    { id: 'mussarela', nome: 'Mussarela', preco: 5 },
    { id: 'calabresa', nome: 'Calabresa', preco: 5 },
    { id: 'bacon', nome: 'Bacon', preco: 5 },
    { id: 'frango', nome: 'Frango', preco: 5 },
    { id: 'milho', nome: 'Milho', preco: 2 },
    { id: 'tomate', nome: 'Tomate', preco: 2 },
    { id: 'ovo', nome: 'Ovo', preco: 2 },
    { id: 'batata-palha', nome: 'Batata palha', preco: 3 },
  ],

  // Os dois cardápios impressos da casa: pastéis (lousa vermelha) e lanches (lousa preta).
  grupos: [
    { id: 'pasteis', nome: 'Pastéis', marca: 'PASTEL', lousa: 'vermelha' },
    { id: 'lanches', nome: 'Lanches e bebidas', marca: 'LANCHES', lousa: 'preta' },
  ],

  // rotulo: como o item aparece na sacola e na mensagem ("X-Bacon (lanche)").
  // foto.real = true → foto da própria casa (Instagram). false → imagem ilustrativa.
  categorias: [
    {
      id: 'pasteis-simples', grupo: 'pasteis', nome: 'Pastéis simples', rotulo: 'pastel',
      foto: { arquivo: 'pasteis-prato', real: false, alt: 'Dois pastéis dourados num prato, ao lado de queijo ralado' },
      itens: [
        { id: 'ps-carne', nome: 'Carne', desc: 'Carne moída com um toque de orégano', preco: 13 },
        { id: 'ps-frango', nome: 'Frango', desc: 'Frango desfiado bem temperadinho', preco: 13 },
        { id: 'ps-queijo', nome: 'Queijo', desc: 'Mussarela e um toque de orégano', preco: 13 },
        { id: 'ps-calabresa', nome: 'Calabresa', desc: 'Calabresa, tomate e cebola', preco: 13 },
        { id: 'ps-carne-ovo', nome: 'Carne com ovo', desc: 'Carne moída, ovo e azeitona', preco: 14 },
        { id: 'ps-carne-queijo', nome: 'Carne com queijo', desc: 'Carne moída, milho e mussarela', preco: 14 },
        { id: 'ps-2-queijos', nome: '2 Queijos', desc: 'Mussarela e catupiry', preco: 15 },
        { id: 'ps-bacon', nome: 'Bacon', desc: 'Bacon com mussarela', preco: 15 },
        { id: 'ps-pizza', nome: 'Pizza', desc: 'Mussarela, presunto, tomate e orégano', preco: 15 },
      ],
    },
    {
      id: 'pasteis-especiais', grupo: 'pasteis', nome: 'Pastéis especiais', rotulo: 'pastel especial',
      foto: { arquivo: 'pasteis-travessa', real: false, alt: 'Pastéis crocantes empilhados numa travessa branca' },
      itens: [
        { id: 'pe-frango-queijo', nome: 'Frango com queijo', desc: 'Frango desfiado e mussarela', preco: 15 },
        { id: 'pe-frango-catupiry', nome: 'Frango com catupiry', desc: 'Frango desfiado e catupiry', preco: 15 },
        { id: 'pe-francheddar', nome: 'Francheddar', desc: 'Frango desfiado e cheddar', preco: 15 },
        { id: 'pe-brocolis-bacon', nome: 'Brócolis com bacon', desc: 'Brócolis, mussarela e bacon', preco: 15 },
        { id: 'pe-brocolis-alho', nome: 'Brócolis com alho frito', desc: 'Brócolis, mussarela e alho frito', preco: 15 },
        { id: 'pe-costela', nome: 'Costela', desc: 'Costela desfiada e tomate', preco: 16 },
        { id: 'pe-franbacon', nome: 'Franbacon', desc: 'Frango desfiado, bacon, tomate e cebola', preco: 16 },
        { id: 'pe-milho-2-queijos', nome: 'Milho e 2 queijos', desc: 'Milho, mussarela e catupiry', preco: 17 },
        { id: 'pe-hotdog', nome: 'Hotdog', desc: 'Purê de batata, salsicha, milho, ketchup, mussarela e orégano', preco: 17 },
        { id: 'pe-costela-queijo', nome: 'Costela com queijo', desc: 'Costela desfiada, mussarela e tomate', preco: 18 },
        { id: 'pe-costela-cream', nome: 'Costela com cream cheese', desc: 'Costela desfiada, cream cheese e tomate', preco: 18 },
        { id: 'pe-calafrango', nome: 'Calafrango', desc: 'Frango, calabresa e mussarela', preco: 18 },
        { id: 'pe-escondidinho', nome: 'Escondidinho de carne', desc: 'Purê de batata, carne moída e mussarela', preco: 19 },
        { id: 'pe-frango-especial', nome: 'Frango especial', desc: 'Frango desfiado, bacon, brócolis, tomate e cream cheese', preco: 20 },
        { id: 'pe-costela-especial', nome: 'Costela especial', desc: 'Costela, brócolis, tomate, bacon e cream cheese', preco: 22 },
      ],
    },
    {
      id: 'pasteis-doces', grupo: 'pasteis', nome: 'Pastéis doces', rotulo: 'pastel doce',
      nota: 'Todos os pastéis doces são passados no açúcar e canela.',
      foto: { arquivo: 'pastel-doce', real: false, alt: 'Massa dourada recheada de chocolate, polvilhada de açúcar' },
      itens: [
        { id: 'pd-brigadeiro', nome: 'Brigadeiro', desc: 'Chocolate e granulado', preco: 14 },
        { id: 'pd-prestigio', nome: 'Prestígio', desc: 'Chocolate e coco ralado', preco: 14 },
        { id: 'pd-romeu-julieta', nome: 'Romeu e Julieta', desc: 'Mussarela e goiabada', preco: 14 },
        { id: 'pd-banana', nome: 'Banana com doce de leite', desc: 'Banana, doce de leite e canela', preco: 14 },
        { id: 'pd-ouro-branco', nome: 'Ouro Branco', desc: 'Chocolate branco e bombom Ouro Branco', preco: 17 },
        { id: 'pd-sonho-valsa', nome: 'Sonho de Valsa', desc: 'Chocolate ao leite e bombom Sonho de Valsa', preco: 17 },
        { id: 'pd-beijinho', nome: 'Bombom beijinho', desc: 'Chocolate branco, coco ralado, beijinho e bombom de beijinho', preco: 17 },
        { id: 'pd-confete', nome: 'Confete', desc: 'Chocolate ao leite e confete', preco: 17 },
        { id: 'pd-pacoca', nome: 'Paçoca', desc: 'Creme de paçoca e paçoca', preco: 17 },
      ],
    },
    {
      id: 'hot-dogs', grupo: 'lanches', nome: "Hot dogs", sub: 'Pão cachorrão', rotulo: 'hot dog', aceitaAdicionais: true,
      foto: { arquivo: 'real-duplo-cheddar', real: true, alt: 'Cachorro-quente duplo cheddar cortado ao meio, segurado na mão', legenda: 'Duplo cheddar, foto do Instagram da casa' },
      itens: [
        { id: 'hd-simples', nome: 'Dog simples', desc: '1 salsicha, batata palha, maionese, ketchup, mostarda, milho e tomate', preco: 10 },
        { id: 'hd-duplo', nome: 'Dog duplo', desc: '2 salsichas, batata palha, maionese, ketchup, mostarda, milho e tomate', preco: 11 },
        { id: 'hd-frango', nome: 'Dog frango', desc: '1 salsicha, batata palha, maionese, ketchup, mostarda, milho, tomate e frango', preco: 14 },
        { id: 'hd-calabresa', nome: 'Dog calabresa', desc: '1 salsicha, batata palha, maionese, ketchup, mostarda, milho, tomate e calabresa', preco: 15 },
        { id: 'hd-bacon', nome: 'Dog bacon', desc: '1 salsicha, batata palha, maionese, ketchup, mostarda, milho, tomate e bacon', preco: 16 },
        {
          id: 'hd-duplo-catupiry', nome: 'Duplo catupiry', desc: '2 salsichas, batata palha, maionese, ketchup, mostarda, milho, tomate e catupiry', preco: 18,
          foto: { arquivo: 'real-duplo-catupiry', real: true, alt: 'Duplo catupiry cortado ao meio, com salsicha e catupiry derretido', legenda: 'Foto do Instagram da casa' },
        },
        {
          id: 'hd-duplo-cheddar', nome: 'Duplo cheddar', desc: '2 salsichas, batata palha, maionese, ketchup, mostarda, milho, tomate e cheddar', preco: 19,
          foto: { arquivo: 'real-duplo-cheddar', real: true, alt: 'Duplo cheddar cortado ao meio, com salsicha e cheddar', legenda: 'Foto do Instagram da casa' },
        },
        { id: 'hd-duplo-cream', nome: 'Duplo cream cheese', desc: '2 salsichas, batata palha, maionese, ketchup, mostarda, milho, tomate e cream cheese', preco: 19 },
      ],
    },
    {
      id: 'lanches', grupo: 'lanches', nome: 'Lanches', sub: 'Pão redondo', rotulo: 'lanche', aceitaAdicionais: true,
      foto: { arquivo: 'lanche-fundo-vermelho', real: false, alt: 'Hambúrguer com queijo derretido sobre tábua de madeira' },
      itens: [
        { id: 'la-bauru', nome: 'Bauru', desc: 'Maionese, ketchup, mostarda, tomate, alface, presunto e mussarela', preco: 12 },
        { id: 'la-x-egg', nome: 'X-Egg', desc: 'Hambúrguer, ovo, presunto, mussarela, maionese, ketchup, mostarda, batata palha, milho e tomate', preco: 20 },
        { id: 'la-especial', nome: 'Especial', desc: '1 salsicha, calabresa, bacon, batata palha, maionese, ketchup, mostarda, milho, tomate e mussarela', preco: 23 },
        { id: 'la-misturado', nome: 'Misturado', desc: 'Maionese, ketchup, mostarda, batata palha, milho, tomate, calabresa fatiada, bacon fatiado, frango desfiado e mussarela', preco: 24 },
        { id: 'la-franbacon', nome: 'Franbacon', desc: 'Batata palha, maionese, ketchup, mostarda, milho, tomate, mussarela, bacon, frango e catupiry', preco: 26 },
        { id: 'la-calafrango', nome: 'Calafrango', desc: 'Batata palha, maionese, ketchup, mostarda, milho, tomate, mussarela, calabresa, frango e catupiry', preco: 26 },
        { id: 'la-x-calabresa', nome: 'X-Calabresa', desc: 'Maionese, ketchup, mostarda, batata palha, milho, tomate, calabresa fatiada, hambúrguer e mussarela', preco: 26 },
        { id: 'la-x-bacon', nome: 'X-Bacon', desc: 'Maionese, ketchup, mostarda, batata palha, milho, tomate, bacon fatiado, hambúrguer e mussarela', preco: 26 },
        { id: 'la-frangao', nome: 'Frangão', desc: 'Maionese, ketchup, mostarda, batata palha, milho, tomate, frango, catupiry e mussarela', preco: 26 },
        { id: 'la-x-salada', nome: 'X-Salada', desc: 'Maionese, ketchup, mostarda, batata palha, milho, tomate, 2 hambúrgueres, mussarela, presunto e alface', preco: 26 },
        {
          id: 'la-costela', nome: 'Costela', desc: 'Costela desfiada, cebola roxa, tomate e cream cheese ou mussarela', preco: 33,
          opcoes: { titulo: 'Escolha o queijo', rotulo: 'Queijo', escolhas: ['Cream cheese', 'Mussarela'] },
        },
        { id: 'la-tudao', nome: 'Tudão', desc: 'Costela desfiada, frango desfiado, calabresa, bacon, ovo, hambúrguer, salsicha, presunto, mussarela, catupiry, cheddar, maionese, ketchup, mostarda, batata palha, milho e tomate', preco: 37 },
      ],
    },
    {
      id: 'lanches-doces', grupo: 'lanches', nome: 'Lanches doces', sub: 'Pão brioche', rotulo: 'lanche doce',
      itens: [
        { id: 'ld-banoffe', nome: 'Banoffe', desc: 'Banana, doce de leite, biscoito, chantilly e canela', preco: 15 },
        { id: 'ld-sensacao', nome: 'Sensação', desc: 'Chocolate e morango', preco: 15 },
      ],
    },
    {
      id: 'bebidas', grupo: 'lanches', nome: 'Bebidas', rotulo: '',
      foto: { arquivo: 'milkshakes', real: false, alt: 'Copos de milkshake com chantilly' },
      itens: [
        { id: 'be-coca-lata', nome: 'Coca-Cola lata', desc: '', preco: 6 },
        { id: 'be-coca-2l', nome: 'Coca-Cola 2 litros', desc: '', preco: 15 },
        {
          id: 'be-milkshake', nome: 'Milkshake 300 ml', desc: 'Sabores Fini banana e Fini dentadura', preco: 18,
          opcoes: { titulo: 'Escolha o sabor', rotulo: 'Sabor', escolhas: ['Fini banana', 'Fini dentadura'] },
        },
        { id: 'be-milkshake-gourmet', nome: 'Milkshake gourmet 300 ml', desc: 'Consulte os sabores pelo WhatsApp', preco: 22, naMensagem: 'Sabor a combinar' },
      ],
    },
  ],
};
