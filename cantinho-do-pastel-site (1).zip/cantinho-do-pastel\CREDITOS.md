# Créditos das imagens

## Da própria casa (Instagram @cantinhodopastel_itabera)
Usadas com a legenda "Foto da casa" / "Foto do Instagram da casa". Baixadas em 2026-10-10.

| Arquivo | Post |
|---|---|
| fotos/real-calafrango-*.webp | https://www.instagram.com/p/DXr8ZOXkeQr/ ("Calafrango caprichado não pode faltar", 28/04/2026) |
| fotos/real-duplo-catupiry-*.webp | https://www.instagram.com/p/DXr8hcjkTvw/ ("Duplo catupiry não pode faltar", 28/04/2026) |
| fotos/real-duplo-cheddar-*.webp | https://www.instagram.com/p/DXr8PLAEa2P/ ("Quem aí ama um cachorro quente duplo cheddar?", 28/04/2026) |
| marca/logo-cantinho-do-pastel.png, img/logo*.webp, ícones | foto de perfil do Instagram (print enviado pelo dono), recortada em círculo com fundo transparente |

## Ilustrativas (Pexels — licença Pexels: uso comercial gratuito, sem obrigação de crédito)
O site marca cada uma como "Imagem ilustrativa". Trocar por fotos da casa quando houver (mesmo nome de arquivo).

| Arquivo | Original |
|---|---|
| fotos/pastel-fritando-*.webp | https://www.pexels.com/photo/24962986/ |
| fotos/pasteis-prato-*.webp | https://www.pexels.com/photo/6054485/ |
| fotos/pasteis-travessa-*.webp | https://www.pexels.com/photo/15010282/ |
| fotos/pastel-doce-*.webp | https://www.pexels.com/photo/31042728/ |
| fotos/dog-na-mao-*.webp | https://www.pexels.com/photo/36501088/ |
| fotos/lanche-fundo-vermelho-*.webp | https://www.pexels.com/photo/37296924/ |
| fotos/milkshakes-*.webp | https://www.pexels.com/photo/32938774/ |
